from cryptography.fernet import Fernet

def WriteFile(Root, Content):

    with open(str(Root), "w") as f:
        
        f.write(Content)

def ScrambelIP(IP):

    XList_IP = ''
    List_IP = IP.split('.')

    XList_IP += List_IP[3]
    XList_IP += List_IP[2]
    XList_IP += List_IP[1]
    XList_IP += List_IP[0]

    return XList_IP

def RemoveFromList(List, remove):

    Len_list = len(List)
    Index = 0

    while Index != Len_list:
        if List[Index] == remove:
            List.remove(Index)
        Index += 1
    return List

def ReplaceInList(list, find, replace): #the code in line 2 is a moddifyde version of public code, not mine! Source: https://stackoverflow.com/questions/24201926/in-place-replacement-of-all-occurrences-of-an-element-in-a-list-in-python
   list[:] = [x if x != find else replace for x in list]
   return list