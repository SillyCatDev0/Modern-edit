import socket
import math

Is_connected = False

def connect(IP):

    global connectip
    global Is_connected
    connectip=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    connectip.connect((IP,7331))
    Is_connected = True

def disconnect():

    global Is_connected

    connectip.close()
    Is_connected = False

def send(Type, Code):
    if Is_connected == False:
        print('SocketTCP Error: Unconnected')
        return Is_connected
    Code = str(Code)
    Code = Code.replace(' ', '')
    Code = Code.replace('\n', '')
    Code = Code.replace('#', '')

    if Type == 'ASM':

        l = [Code[i:i+16] for i in range(0,len(Code), 16)]
        i=0
        while i < len(l):
            connectip.send(bytes.fromhex('03'))
            connectip.send(bytes.fromhex(l[i]))
            i += 1

    if Type == 'Cafe':

        for x in range(math.floor(len(Code)/8)):
            connectip.send(bytes.fromhex('03'))
            connectip.send(bytes.fromhex('0'+format(0x01133000+x*4,'X')+Code[x*8:x*8+8]))
        connectip.send(bytes.fromhex('03'))
        connectip.send(bytes.fromhex('10014CFC00000001'))