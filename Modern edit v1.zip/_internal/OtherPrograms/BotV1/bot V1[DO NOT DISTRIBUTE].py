from discord.ext import commands
import discord
import JBT

File_Root = __file__.replace("bot V1[DO NOT DISTRIBUTE].py", "")

Info_Root = File_Root + 'BotV1_Info.txt'
Info_Read = open(Info_Root).read()

token = "MTIyODU2NzM1NDc5MTgyNTUyMA.Ge1atz.km9C5oG-dmdQ85PWvZuTtuztw5TZE_kb7RvtZk"
channel_id__bot = 1228602426286805022
channel_id__log = 1228626112956076122
bot = commands.Bot(command_prefix = '\\', intents = discord.Intents.all())

MochaID = 1181047542105002050

@bot.event
async def on_ready():

    channel = bot.get_channel(channel_id__bot)
    await channel.send('Running...')

@bot.command()
async def echo(h, echo):

    echo = str(echo).replace('<~space~>', " ")

    channel = bot.get_channel(channel_id__log)
    await channel.send('``` Log: Command echo(' + 'echo = ' + '\'' + echo + '\'' + ') was called ```')

    await h.send(echo)

@bot.command()
async def spam(h, user, message):

    message = str(message).replace('<~space~>', " ")
    
    channel = bot.get_channel(channel_id__log)
    await channel.send('``` Log: Command spam(' + 'user = ' + user + ', message = ' + '\'' +message + '\'' + ') was called ```')

    times = 0

    while times != 50:

        dmuser = await bot.fetch_user(user)
        await dmuser.send(message)

        times += 1

@bot.command()
async def store(h, text):

    JBT.WriteFile(Info_Root, Info_Read + '\n' + text)

bot.run(token)